$(document).ready(function() {

   //Side Nav
   $('.sidenav').sidenav();

   //Input Mask
   $("#search").inputmask("999-99-99");

	 //Modal
	 $('.modal').modal();

   //Modal Close
   $("#cancel-btn").click(function(e){
      e.preventDefault();
      $('.modal').modal('close');
   });

   //Dropdown
   $(".dropdown-trigger").dropdown();

   //Carousel
   $('.carousel').carousel();

   //Reset Button
   $("#reset-btn").click(function(){
      location.reload();
   });

   //Tooltip
   $('.tooltipped').tooltip();

   //Search Action
   $("#search-btn").click(function(e){
   	e.preventDefault();
   	
      var prefix = $("#prefixSearch").val();
      var categoryId = $("#categorySearch").val();
      var number = $("#search").val();

      if (prefix == '') {
         M.toast({html: 'Please choose prefix', classes: 'red'});
         return;
      }

      if (categoryId == '') {
         M.toast({html: 'Please choose category', classes: 'red'});
         return;
      }

      if (number == '') {
         M.toast({html: 'Please write number', classes: 'red'});
         return;
      }

      var url = 'https://reserve-number.ilkin-guluzada.com/index.php/api/number/search/'+prefix+'/'+number+'/'+categoryId;

      $("#search-form").toggle();
      $(".loading").toggle();

      $.ajax({
          url : url,
          type : 'GET',
          dataType:'json',
          success : function(data) { 
            if (data.length > 0) {
               $("#search-found-number").text(data[0].number);
               $("#search-found-number").attr("data-id", data[0].number);
               $("#search-found-price").text(data[0].price + " ₼");
               $(".search-success").toggle();
            }else{
               $(".search-fail").toggle();
            }
            
            $(".loading").toggle();
            $(".result").toggle();
          },
          error : function(request,error)
          {
              alert("Request: "+JSON.stringify(request));
          }
      });

   });

   //Seach Again Action
   $("#search-again").click(function(e){
      e.preventDefault();
      location.reload();
   });

   //Reserve Form Open
   $('.list-numbers').on('click', function () {
      var number = $(this).text();
      var price = $(this).attr("data-tooltip");
      var number_id = $(this).attr("data-id");

      $("#icon_telephone_label").text(number);
      $("#icon_price_label").text(price);
      $("#icon_telephone_label").attr("data-id", number_id);
   });

   //Found Number Form Open
   $('.found-number').on('click', function () {
      var number = $("#search-found-number").text();
      var price = $("#search-found-price").text();
      var number_id = $("#search-found-number").attr("data-id");

      $("#icon_telephone_label").text(number);
      $("#icon_price_label").text(price);
      $("#icon_telephone_label").attr("data-id", number_id);
   });

   //Reserve Action
   $("#reserve-btn").click(function(e){
      e.preventDefault();

      var phone = $("#icon_phone").val();
      var number = $("#icon_telephone_label").text();
      var number_id = $("#icon_telephone_label").attr("data-id");

      if (phone == "") {
         M.toast({html: 'Please write your number', classes: 'red'});
         return;
      }

      $("#reserve-form").toggle();
      $(".loading-form").toggle();

      var data = {
         "number_id": number_id,
         "phone": phone
      }

      $.ajax({
          url : 'https://reserve-number.ilkin-guluzada.com/index.php/api/number/reserve/',
          type : 'POST',
          dataType:'json',
          data: data,
          success : function(data) { 
            if (data.length > 0) {
               $("#code1").text(data[0]);
               $("#code2").text(data[1]);
               $("#code3").text(data[2]);
               $("#code4").text(data[3]);
               $("#code5").text(data[4]);
               $("#code6").text(data[5]);
               $(".loading-form").toggle();
               $("#success-msg").toggle();
            }
          },
          error : function(request,error)
          {
              alert("Request: "+JSON.stringify(request));
          }
      });

   });

   
});