<?php $active_menu=$this->session->userdata('active_menu');
?>
 <!-- Side-Nav-->
<aside class="main-sidebar hidden-print">
    <section class="sidebar">
        <!-- Sidebar Menu-->
        <ul class="sidebar-menu">
            <li calss="<?php if($active_menu==1) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/dashboard';?>" class="waves-effect waves-light <?php if($active_menu==1) {echo "active"; } ?>" id="65"><i class="lnr lnr-home"></i><span>Dashboard</span> </a> </li>

            <li class="treeview <?php if($active_menu==4 || $active_menu==5 ) {echo "active"; } ?>"> <a href="#" class="waves-effect waves-light" ><i class="fa fa-phone" aria-hidden="true"></i><span>Numbers</span> <i class="fa fa-angle-right"></i></a>
              <ul class="treeview-menu">
                <li class="<?php if($active_menu==4) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/numbers_add/'?>" class="waves-effect waves-light <?php if($active_menu==2) {echo "active"; } ?>"><i class="fa fa-plus" aria-hidden="true"></i>New Numbers</span> </a></li>
                <li class="<?php if($active_menu==5) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/numbers/'?>" class="waves-effect waves-light <?php if($active_menu==3) {echo "active"; } ?>"><i class="fa fa-list" aria-hidden="true"></i>All Numbers</span> </a></li>
              </ul>
            </li>

            <li class="treeview <?php if($active_menu==6 || $active_menu==7 ) {echo "active"; } ?>"> <a href="#" class="waves-effect waves-light" ><i class="fa fa-align-left" aria-hidden="true"></i><span>Categories</span> <i class="fa fa-angle-right"></i></a>
              <ul class="treeview-menu">
                <li class="<?php if($active_menu==6) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/categories_add/'?>" class="waves-effect waves-light <?php if($active_menu==6) {echo "active"; } ?>"><i class="fa fa-plus" aria-hidden="true"></i>New Category</span> </a></li>
                <li class="<?php if($active_menu==7) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/categories/'?>" class="waves-effect waves-light <?php if($active_menu==7) {echo "active"; } ?>"><i class="fa fa-list" aria-hidden="true"></i>All Categories</span> </a></li>
              </ul>
            </li>

            <li class="treeview <?php if($active_menu==8 || $active_menu==9 ) {echo "active"; } ?>"> <a href="#" class="waves-effect waves-light" ><i class="fa fa-map-marker" aria-hidden="true"></i><span>Seller Locations</span> <i class="fa fa-angle-right"></i></a>
              <ul class="treeview-menu">
                <li class="<?php if($active_menu==8) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/sellerlocations_add/'?>" class="waves-effect waves-light <?php if($active_menu==8) {echo "active"; } ?>"><i class="fa fa-plus" aria-hidden="true"></i>New Location</span> </a></li>
                <li class="<?php if($active_menu==9) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/sellerlocations/'?>" class="waves-effect waves-light <?php if($active_menu==9) {echo "active"; } ?>"><i class="fa fa-list" aria-hidden="true"></i>All Locations</span> </a></li>
              </ul>
            </li>
            
            <li class="<?php if($active_menu==15) {echo "active"; } ?>"> <a href="<?php echo base_url().'admin/manage_user/'?>" class="waves-effect waves-light <?php if($active_menu==15) {echo "active"; } ?>"><i class="fa fa-user" aria-hidden="true"></i>Users</span> </a></li>

        </ul>
    </section>
</aside>
        