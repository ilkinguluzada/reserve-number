<div class="card">
  <div class="row">
    <div class="col-sm-12">
        <div class="btn-group dropdown pull-right">
          <button type="button" class="btn btn-primary btn-sm waves-effect waves-light text-capital">
          <?php
            switch ($type) {
              case 'published':
                echo 'PUBLISHED';
                break;
              case 'unpublished':
                echo 'UNPUBLISHED';
                break;                
              default:
                echo 'FILTER';
                break;
            }
            ?>
          </button>
          <button type="button" class="btn btn-primary dropdown-toggle waves-effect waves-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="caret"></i></button>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo base_url().'admin/categories/published'?>"><?php echo tr_wd('published'); ?></a></li>
            <li><a href="<?php echo base_url().'admin/categories/unpublished'?>"><?php echo tr_wd('unpublished'); ?></a></li>
            <li><a href="<?php echo base_url().'admin/categories/'?>"><?php echo tr_wd('all_categories'); ?></a></li>
          </ul>
        </div>
        <a href="<?php echo base_url() . 'admin/categories_add';?>" class="btn btn-sm btn-primary waves-effect waves-light"><span class="btn-label"><i class="fa fa-plus"></i></span><?php echo tr_wd('add_category'); ?></a> <br>
        <br>
        <table id="datatable" class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>#</th>
              <th><?php echo tr_wd('Category'); ?></th>
              <th><?php echo tr_wd('Description'); ?></th>
              <th><?php echo tr_wd('Starting Price'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $sl = 1;                                
            switch ($type) {
              case 'published':
                $this->db->order_by('id','DESC');
                $categories=$this->db->get_where('categories', array('publication' => '1'))->result_array();
                break;
              case 'unpublished':
                $this->db->order_by('id','DESC');
                $categories=$this->db->get_where('categories', array('publication' => '0'))->result_array();
                break;
              default:
                  $this->db->order_by('id','DESC');
                  $categories=$this->db->get('categories')->result_array();                  
                  break;
            }                                
            foreach ($categories as $categories):                     

            ?>
            <tr id='row_<?php echo $categories['id'];?>'>                
              <td><div class="btn-group">
                  <button type="button" class="btn btn-white btn-sm dropdown-toggle waves-effect waves-light" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a  href="<?php echo base_url() . 'admin/categories_edit/'. $categories['id'];?>"><?php echo tr_wd('edit_category'); ?></a></li>
                    <li><a title="<?php echo tr_wd('delete'); ?>" href="#" onclick="delete_book(<?php echo " 'categories' ".','.$categories['id'];?>)" class="delete"><?php echo tr_wd('delete'); ?></a> </li>
                  </ul>
                </div>
              </td>
                <td><?php echo $sl++;?></td>
                <td><strong><?php echo $categories['category'];?></strong></td>
                <td><strong><?php echo substr($categories['description'], 0,50);?>...</strong></td>
                <td><strong><?php echo $categories['starting_price'];?> ₼</strong></td>             
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/parsleyjs/dist/parsley.min.js"></script> 
<script type="text/javascript">
    $(document).ready(function() {
        $('form').parsley();
    });
</script> 

<!-- date picker--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script> 
<!-- date picker--> 
<!-- file select--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-filestyle/src/bootstrap-filestyle.min.js" type="text/javascript"></script> 
<!-- file select--> 
<!-- select2--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url() ?>assets/plugins/select2/select2.min.js" type="text/javascript"></script> 
<!-- select2--> 
