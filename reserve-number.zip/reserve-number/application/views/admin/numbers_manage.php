<div class="card">
  <div class="row">
    <div class="col-sm-12">
        <div class="btn-group dropdown pull-right">
          <button type="button" class="btn btn-primary btn-sm waves-effect waves-light text-capital">
          <?php
            switch ($type) {
              case 'published':
                echo 'PUBLISHED';
                break;
              case 'unpublished':
                echo 'UNPUBLISHED';
                break;                
              default:
                echo 'FILTER';
                break;
            }
            ?>
          </button>
          <button type="button" class="btn btn-primary dropdown-toggle waves-effect waves-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="caret"></i></button>
          <ul class="dropdown-menu" role="menu">
            <li><a href="<?php echo base_url().'admin/numbers/published'?>"><?php echo tr_wd('published'); ?></a></li>
            <li><a href="<?php echo base_url().'admin/numbers/unpublished'?>"><?php echo tr_wd('unpublished'); ?></a></li>
            <li><a href="<?php echo base_url().'admin/numbers/'?>"><?php echo tr_wd('all_numbers'); ?></a></li>
          </ul>
        </div>
        <a href="<?php echo base_url() . 'admin/numbers_add';?>" class="btn btn-sm btn-primary waves-effect waves-light"><span class="btn-label"><i class="fa fa-plus"></i></span><?php echo tr_wd('add_number'); ?></a> <br>
        <br>
        <table id="datatable" class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>#</th>
              <th><?php echo tr_wd('Prefix'); ?></th>
              <th><?php echo tr_wd('Number'); ?></th>
              <th><?php echo tr_wd('Price'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $sl = 1;                                
            switch ($type) {
              case 'published':
                $this->db->order_by('id','DESC');
                $numbers=$this->db->get_where('numbers', array('publication' => '1'))->result_array();
                break;
              case 'unpublished':
                $this->db->order_by('id','DESC');
                $numbers=$this->db->get_where('numbers', array('publication' => '0'))->result_array();
                break;
              default:
                  $this->db->order_by('id','DESC');
                  $numbers=$this->db->get('numbers')->result_array();                  
                  break;
            }                                
            foreach ($numbers as $numbers):                     

            ?>
            <tr id='row_<?php echo $numbers['id'];?>'>                
              <td><div class="btn-group">
                  <button type="button" class="btn btn-white btn-sm dropdown-toggle waves-effect waves-light" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-h" aria-hidden="true"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a  href="<?php echo base_url() . 'admin/numbers_edit/'. $numbers['id'];?>"><?php echo tr_wd('edit_number'); ?></a></li>
                    <li><a title="<?php echo tr_wd('delete'); ?>" href="#" onclick="delete_book(<?php echo " 'numbers' ".','.$numbers['id'];?>)" class="delete"><?php echo tr_wd('delete'); ?></a> </li>
                  </ul>
                </div>
              </td>
                <td><?php echo $sl++;?></td>
              <td><strong><?php echo $numbers['prefix'];?></strong></td>                
              <td><strong><?php echo $numbers['number'];?></strong></td>
              <td><strong><?php echo $numbers['price'];?> ₼</strong></td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/parsleyjs/dist/parsley.min.js"></script> 
<script type="text/javascript">
    $(document).ready(function() {
        $('form').parsley();
    });
</script> 

<!-- date picker--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script> 
<!-- date picker--> 
<!-- file select--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-filestyle/src/bootstrap-filestyle.min.js" type="text/javascript"></script> 
<!-- file select--> 
<!-- select2--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url() ?>assets/plugins/select2/select2.min.js" type="text/javascript"></script> 
<!-- select2--> 
