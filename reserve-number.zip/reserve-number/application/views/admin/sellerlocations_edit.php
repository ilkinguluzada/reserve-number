  <div class="card">
    <div class="row">
      <div class="col-sm-12">
        <?php 
          $sellerlocations   = $this->db->get_where('seller_locations' , array('id' => $param1) )->result_array();
            foreach ( $sellerlocations as $category):
        ?>
        <?php echo form_open(base_url() . 'admin/sellerlocations/update/'.$param1 , array('class' => 'form-horizontal group-border-dashed', 'enctype' => 'multipart/form-data'));?>
          <h4 class="text-center"><?php echo tr_wd('add_new_category') ?></h4>
          <hr>

          <div class="form-group">
            <label class=" col-sm-3 control-label"><?php echo tr_wd('name'); ?></label>
            <div class="col-sm-8">
              <input type="text" value="<?php echo $category['name'] ?>" name="name" id="name" class="form-control" required>
            </div>
          </div>

          <div class="form-group">
            <label class=" col-sm-3 control-label"><?php echo tr_wd('address'); ?></label>
            <div class="col-sm-8">
              <input type="text" value="<?php echo $category['address'] ?>" name="address" id="address" class="form-control" required>
            </div>
          </div>

          <div class="form-group">
            <label class=" col-sm-3 control-label"><?php echo tr_wd('phone'); ?></label>
            <div class="col-sm-8">
              <input type="text" value="<?php echo $category['phone'] ?>" name="phone" id="phone" class="form-control" required>
            </div>
          </div>

          <div class="form-group">
            <label class=" col-sm-3 control-label"><?php echo tr_wd('latitude'); ?></label>
            <div class="col-sm-8">
              <input type="text" value="<?php echo $category['lat'] ?>" name="lat" id="lat" class="form-control" required>
            </div>
          </div>

          <div class="form-group">
            <label class=" col-sm-3 control-label"><?php echo tr_wd('longitude'); ?></label>
            <div class="col-sm-8">
              <input type="text" value="<?php echo $category['lng'] ?>" name="lng" id="lng" class="form-control" required>
            </div>
          </div>

          <?php endforeach; ?>
          <div class="form-group">
            <div class="col-sm-offset-3 col-sm-9 m-t-15">
              <button type="submit" class="btn btn-sm btn-success waves-effect"> <span class="btn-label"><i class="fa fa-floppy-o"></i></span><?php echo tr_wd('save'); ?> </button>
            </div>
          </div>
        <?php echo form_close(); ?>

<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/parsleyjs/dist/parsley.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('form').parsley();
    });

</script>

<!-- select2-->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/plugins/select2/select2.min.js" type="text/javascript"></script>
<!-- select2-->


<!--form validation init-->
<script src="<?php echo base_url() ?>assets/plugins/summernote/dist/summernote.min.js"></script>
<script>
    jQuery(document).ready(function() {
        $('#description').summernote({
            height: 200,
            minHeight: null,
            maxHeight: null,
            focus: false
        });
    });
</script>
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>

<!-- file select-->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-filestyle/src/bootstrap-filestyle.min.js" type="text/javascript"></script>
<!-- file select-->