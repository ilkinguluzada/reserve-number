<div class="card">
  <div class="row">
    <div class="col-sm-12">
        <?php echo form_open(base_url() . 'admin/numbers/add/' , array('class' => 'form-horizontal group-border-dashed', 'enctype' => 'multipart/form-data'));?>
        <h4 class="text-center"><?php echo tr_wd('add_new_number') ?></h4>
        <hr>

        <div class="form-group">
          <label class="control-label col-md-3"><?php echo tr_wd('Prefix'); ?></label>
          <div class="col-sm-8">
            <select class="form-control m-bot15" name="prefix">
              <option value="055">055</option>
              <option value="099">099</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label class=" col-sm-3 control-label"><?php echo tr_wd('number'); ?></label>
          <div class="col-sm-8">
            <input type="text" name="number" id="number" class="form-control" required>
          </div>
        </div>

        <div class="form-group">
          <label class=" col-sm-3 control-label"><?php echo tr_wd('price'); ?></label>
          <div class="col-sm-8">
            <input type="text" name="price" id="price" class="form-control" required>
          </div>
        </div>
       
        <div class="form-group">
          <label class="control-label col-md-3"><?php echo tr_wd('Category'); ?></label>
          <div class="col-sm-8">
            <select class="form-control m-bot15" name="category_id">
              <?php foreach ($categories as $category) { ?>
              <option value="<?php echo $category->id; ?>"><?php echo $category->category; ?></option>
              <?php } ?>
            </select>
          </div>
        </div>

        <div class="form-group">
          <div class="col-sm-offset-3 col-sm-9 m-t-15">
            <button type="submit" class="btn btn-sm btn-primary waves-effect"> <span class="btn-label"><i class="fa fa-plus"></i></span>CREATE </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo form_close(); ?>

<script>
jQuery(document).ready(function() {
  $(".select2").select2();
  $('form').parsley();                    
});
</script> 



<script type="text/javascript" src="<?php echo base_url() ?>assets/plugins/parsleyjs/dist/parsley.min.js"></script> 
<script type="text/javascript">
    $(document).ready(function() {
        $('form').parsley();
    });
</script> 


<!-- select2--> 
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url() ?>assets/plugins/select2/select2.min.js" type="text/javascript"></script> 
<!-- select2--> 

<!--form validation init-->
<script src="<?php echo base_url() ?>assets/plugins/summernote/dist/summernote.min.js"></script>
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<!-- file select-->
<script src="<?php echo base_url() ?>assets/plugins/bootstrap-filestyle/src/bootstrap-filestyle.min.js" type="text/javascript"></script>
<!-- file select-->