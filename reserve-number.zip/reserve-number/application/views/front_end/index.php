<?php include 'language/handle_lang.php'; ?>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="www.ilkin-guluzada.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="<?php echo base_url() . 'assets/front_end/'; ?>css/main.css" rel="stylesheet" />
    
    <title>Reserve Number | By Ilkin Guluzada</title>
  </head>
  <body>      
    <div class="s002 row">      
      <div class="col s10 offset-s1">
          <?php include 'parts/loading.php'; ?> 
          <?php include 'parts/navbar.php'; ?>  
          <?php include 'parts/search-form.php'; ?>
          <?php include 'parts/suggestions.php'; ?>      
          <?php include 'parts/search-result.php'; ?> 
          <?php include 'parts/reserve-modal.php'; ?> 
          <?php include 'parts/seller-locations-modal.php'; ?> 
      </div>   
    </div>
    <script
    src="https://code.jquery.com/jquery-3.5.1.min.js"
    integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
    crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    
    <script src="<?php echo base_url('assets/front_end/'); ?>js/extention/choices.js"></script>
    <script src="<?php echo base_url('assets/front_end/'); ?>js/extention/jquery.inputmask.min.js"></script>
    <script src="<?php echo base_url('assets/front_end/'); ?>js/main.js"></script>

    <script>
      const choices = new Choices('[data-trigger]',
      {
        searchEnabled: true,
        itemSelectText: '',
      });
    </script>
    
    <!-- Google Map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBdO9SCzmPekAzPSwRfbKoK856aAOnMIx4"
    type="text/javascript"></script>
    <!-- Google Map End -->

    <script>
      $(document).ready(function() {
        function initMap() {

            //Markerlerin yeri
            var locations = [];
            var locationIds = [];

            //Markerlerin yerini fetch edib arrayi doldurururq
            <?php  $result_seller_locations = $this->admin_model->get_sellerlocations();

              foreach($result_seller_locations as $row){                   
                  $seller_location_id = $row['id'];
                  $seller_location_name = $row['name'];
                  $seller_location_address = $row['address'];
                  $seller_location_phone = $row['phone'];
                  $seller_location_lng = (float) $row['lng'];
                  $seller_location_lat = (float) $row['lat']; 
            ?>

              locations.push(['<?php echo $seller_location_name . "<br> " . $seller_location_phone; ?>', <?php echo $seller_location_lat; ?>, <?php echo $seller_location_lng; ?>, 4])
              locationIds.push(<?php echo (int) $seller_location_id; ?>);
                
            <?php  } ?>
 
            //Markerləri toplamaq üçün
            var markers = new Array(100).fill(null);

            //Xerite yaratmaq
            var map = new google.maps.Map(document.getElementById('map'), {
              zoom: 12,
              center: new google.maps.LatLng(locations[0][1], locations[0][2]),
              mapTypeId: google.maps.MapTypeId.ROADMAP,
            });

            //Info window yaradiram
            var infowindow = new google.maps.InfoWindow();
            var marker, i;

            //Markerleri yaradiriq
            for (i = 0; i < locations.length; i++) {  
                marker = new google.maps.Marker({
                      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                      map: map,
                      icon: '<?php echo base_url('assets/front_end/images/marker.png'); ?>',
                });

                //Sonra ucun yaratdiqlarimi toplayiram
                markers[locationIds[i]] = marker;

                //Markere klik edende
                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                    return function() {
                      infowindow.setContent(locations[i][0]);
                      infowindow.open(map, marker);
                    }
                })(marker, i));
            }        
        }

        //Seller Locations Open
        $('.sellerLocationButton').on('click', function () {
            initMap();
        });
      });
      </script>
  </body>
</html>
