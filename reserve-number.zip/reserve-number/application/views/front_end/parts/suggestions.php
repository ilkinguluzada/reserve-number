<!-- Suggestions -->
<?php foreach ($categories as $category) { ?>
  <div class="result suggestion">
    <div class="row search-info">
      <div class="col m6 s12">
        <small><?php echo $category->starting_price; ?> ₼</small>
        <h1><?php echo $category->category; ?> <?php echo $category_title; ?></h1>
      </div>
      <div class="col m6 s12">
        <p class="text-right"><?php echo $category->description; ?></p>
      </div>
    </div>
    <div class="row numbers">
      <?php  
      $numbers = $this->admin_model->get_numbers_by_category_id($category->id);
      foreach ($numbers as $number) { ?>

        <div class="col m3 s6">
          <a style="background:url(<?php echo base_url('assets/front_end/images/sim.svg'); ?>);" class="modal-trigger tooltipped list-numbers" data-id="<?php echo($number->id); ?>" data-position="bottom" data-tooltip="<?php echo $starting_from; ?> <?php echo($number->price); ?> ₼" href="#customerInfo"><span><?php echo($number->number); ?></span></a>
        </div>
      <?php } ?>
    </div>
  </div>
<?php } ?>
<!-- Suggestions / -->