<!-- Navbar -->
<ul id="dropdown1" class="dropdown-content">
  <li <?php if ($currentLang == 'AZ') { ?> style="display: none" <?php } ?> ><a href="?lang=az">AZ</a></li>
  <li <?php if ($currentLang == 'EN') { ?> style="display: none" <?php } ?>  ><a href="?lang=en">EN</a></li>
  <li <?php if ($currentLang == 'RU') { ?> style="display: none" <?php } ?>  ><a href="?lang=ru">RU</a></li>
</ul>
<nav class="hide-on-med-and-down">
  <div class="nav-wrapper">
    <!-- <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a> -->
    <a href="#!" class="brand-logo">ilkin guluzada.</a>
    <ul class="right">
      <li><a class="modal-trigger sellerLocationButton sellerLocationButtonDesktop" href="#sellerLocations"><i class="material-icons" style="display: inline;">storefront</i><span ><?php echo $seller_location_title; ?></span></a></li>
      
      <li><a class="dropdown-trigger" href="#!" data-target="dropdown1"><?php echo $currentLang; ?><i class="material-icons right">arrow_drop_down</i></a></li>
    </ul>
  </div>
</nav>

<ul id="slide-out" class="sidenav">
  <li><a class="modal-trigger sellerLocationButton" href="#sellerLocations"><i class="material-icons" style="display: inline;">storefront</i><span ><?php echo $seller_location_title; ?></span></a></li>
  
  <li><a class="dropdown-trigger" href="#!" data-target="dropdown1"><?php echo $currentLang; ?><i class="material-icons right">arrow_drop_down</i></a></li>
</ul>
<a href="#" data-target="slide-out" class="sidenav-trigger hide-on-large-only"><i class="material-icons">menu</i></a>
<!-- Navbar /-->