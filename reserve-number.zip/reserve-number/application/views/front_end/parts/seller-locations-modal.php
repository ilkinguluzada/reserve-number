<!-- Seller Location -->
<div style="overflow-y: hidden;" id="sellerLocations" class="modal">
    <div style="padding: 0;" class="modal-content">
      <div id="map" style="width: 100%; height: 600px;"></div>
    </div>
</div>
<!-- Seller Location /-->

