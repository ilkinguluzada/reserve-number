<!-- Contact Modal Starts -->
<div id="customerInfo" style="text-align: center;" class="modal bottom-sheet">
  <div class="modal-content">

    <!-- Form Spinner Loading -->
    <?php include 'loading-form.php'; ?>


    <form class="row" id="reserve-form">
            <p class="col m8 m1 s12 offset-m3"><?php echo $reservation_text; ?></p>
            <div class="input-field col m4 m1 s12 offset-m3 phone-input">
              <i class="material-icons prefix">add_shopping_cart</i>
              <input id="icon_telephone" type="tel" disabled class="validate">
              <label id="icon_telephone_label" for="icon_telephone">XXX XX XX</label>
            </div>
            <div class="input-field col m4 m1 s12 money-input">
              <i class="material-icons prefix">attach_money</i>
              <input id="icon_price" type="tel" disabled class="validate">
              <label id="icon_price_label" for="icon_price"><?php echo $starting_from; ?> XX ₼</label>
            </div>
            <div class="input-field col m8 m1 s12 offset-m3 phone-input">
              <i class="material-icons prefix">phone</i>
              <input id="icon_phone" type="tel" class="validate">
              <label for="icon_phone"><?php echo $phone; ?></label>
            </div>
            <div class="col m4 m1 s12 offset-m3">
              <button class="btn waves-effect waves-light submit-btn" id="reserve-btn" type="submit" name="action"><?php echo $reserve; ?>
                <i class="material-icons right">send</i>
              </button>
            </div>

            <div class="col m4 m1 s12">
              <button class="btn waves-effect waves-light submit-btn red" id="cancel-btn" type="submit" name="action"><?php echo $cancel; ?>
                <i class="material-icons right">cancel</i>
              </button>
            </div>
    </form>

    <div id="success-msg">
      <h5><?php echo $reserve_success; ?></h5>
      <p><?php echo $reserve_success_text; ?></p>

      <div class="inner-form">
        <div class="row">
          <div class="input-field col m1 s2 offset-m3">
            <h4 id="code1" class="code">X</h4>
          </div>
          <div class="input-field col m1 s2">
            <h4 id="code2" class="code">X</h4>
          </div>
          <div class="input-field col m1 s2">
            <h4 id="code3" class="code">X</h4>
          </div>
          <div class="input-field col m1 s2">
            <h4 id="code4" class="code">X</h4>
          </div>
          <div class="input-field col m1 s2">
            <h4 id="code5" class="code">X</h4>
          </div>
          <div class="input-field col m1 s2">
            <h4 id="code6" class="code">X</h4>
          </div>
        </div>
      </div>

    </div>

  </div>
</div>  
<!-- Contact Modal Ends -->