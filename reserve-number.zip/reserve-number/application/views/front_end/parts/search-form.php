<!-- Search Form Starts -->
  <form id="search-form">
    <fieldset>
      <legend><?php echo $home_title; ?></legend>
    </fieldset>
    <div class="inner-form">
      <div class="input-field fouth-wrap">
        <select id="prefixSearch" data-trigger="" name="choices-single-defaul">
          <option value="" placeholder=""><?php echo $prefix; ?></option>
          <option value="055">055</option>
          <option value="099">099</option>
        </select>
      </div>

      <div class="input-field fouth-wrap">
        <select id="categorySearch" data-trigger="" name="choices-single-defaul">
            <option value="" placeholder=""><?php echo $category_title; ?></option>

          <?php foreach ($categories as $category) { ?>
            <option value="<?php echo $category->id; ?>"><?php echo $category->category; ?></option>
          <?php } ?>
        </select>
      </div>

      <div class="input-field first-wrap">
        <input id="search" type="text" placeholder="XXX XX XX" />
      </div>

      <div class="input-field btn-input fifth-wrap">
        <button class="btn-search" id="search-btn" type="button"><?php echo $search; ?></button>
      </div>

      <div class="input-field btn-input fifth-wrap">
        <button class="btn-search" id="reset-btn" type="button"><?php echo $reset; ?></button>
      </div>

    </div>
  </form>
  <!-- Search Form Ends -->