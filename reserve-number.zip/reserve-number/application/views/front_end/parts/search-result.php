<!-- Search Result Starts -->
<div style="display: none;" class="result search-result">
  <div class="row">
    <div class="col m2 s6"><a id="search-again" href="#"> <i class="material-icons">keyboard_backspace</i> <span><?php echo $search_again; ?></span></a></div>
  </div>

  <!-- Found Search -->
  <div style="display: none;" class="row search-info search-success">
    <div class="col m6 s12">
      <h1><?php echo $found; ?></h1>
    </div>
    <div class="col m3 s12">
      <h1><a class="modal-trigger found-number tooltipped" data-position="bottom" data-tooltip="Click to reserve" href="#customerInfo"><span data-id="" id="search-found-number">XXX XX XX</span> <span id="search-found-price" class="price-badge">XX ₼</span></a></h1>
    </div>
  </div>
  <!-- Found Search / -->

  <!-- Not Found Search -->
  <div style="display: none;" class="row search-info search-fail">
    <div class="col m6 s12">
      <h1><?php echo $not_found; ?></h1>
    </div>
  </div>
  <!-- Not Found Search / -->

  <!-- Similar Numbers in Search -->
  <div class="row search-info">
    <div class="col m6 s12">
      <h1><?php echo $similar_numbers; ?></h1>
    </div>
    <div class="col m6 s12">
      <p class="text-right"></p>
    </div>
  </div>
  <div class="row numbers">
      <?php 
      foreach ($numbers as $number) { ?>

        <div class="col m3 s6">
          <a style="background:url(<?php echo base_url('assets/front_end/images/sim.svg'); ?>);" class="modal-trigger tooltipped list-numbers" data-id="<?php echo($number->id); ?>" data-position="bottom" data-tooltip="<?php echo $starting_from; ?> <?php echo($number->price); ?> ₼" href="#customerInfo"><span><?php echo($number->number); ?></span></a>
        </div>
      <?php } ?>
    </div>
</div>
<!-- Similar Numbers in Search -->
