<?php 
    
$home_title = "Reserve Your Number";
$prefix = "Prefix";
$category_title = "Category";
$search = "Search";
$reset = "Reset";
$starting_from = "Starting from ";
$search_again = "Search Again ";
$found = "Yayy! Found! ";
$not_found = "Upss! Not Found!";
$similar_numbers = "Similar Numbers ";
$reserve = "Reserve";
$reserve_success = "Success! Your reserved!";
$reserve_success_text = "The reservation will be active for 1 hour. Take a note of below code, and approach to any dealer store or front office of Bakcell with the reservation code to get your number.";
$reservation_text = "The reservation will be active for 1 hour. After successfully reserving the number, please approach to any dealer store or front office of Bakcell with the reservation code to get your number.";
$cancel = "Cancel";
$phone = "Phone";
$seller_location_title = "Seller Locations";


?>