<?php 

    $home_title = "Nömrə Rezervasiyası";
    $prefix = "Prefiks";
    $category_title = "Kateqoriya";
    $search = "Axtar";
    $reset = "Sıfırla";
    $starting_from = "Qiymət: ";
    $search_again = "Yenidən axtar ";
    $found = "Əla! Tapıldı! ";
    $not_found = "Ups! Tapılmadı! ";
    $similar_numbers = "Oxşar Nömrələr ";
    $reserve = "Rezerv Et";
    $reserve_success = "Uğurlu! Reserv Edildi.";
    $reserve_success_text = "Sizin rezervasiyanız 1 saat müddətində aktiv olacaq. Aşağıdakı sifariş kodunu qeyd edin və nömrənizi əldə etmək üçün bu sifariş kodu ilə Bakcell-in istənilən satış və ya ön ofisinə müraciət edin.";
    $reservation_text = "Sizin rezervasiyanız 1 saat müddətində aktiv olacaq. Nömrəni bron etdikdən sonra nömrənizi əldə etmək üçün sifariş kodu ilə Bakcell-in istənilən satıcısına və ya ön ofisinə müraciət edin.";
    $cancel = "Ləğv et";
    $phone = "Telefon";
    $seller_location_title = "Satış Ofisləri";

 ?>