<?php 
  $currentLang = '';

  if (!isset($_GET['lang'])) {
    require('az.php');
    $currentLang = 'AZ';
  }else{
    $lang = htmlspecialchars(trim($_GET['lang']));
    if ($lang == 'az') {
      require('az.php');
      $currentLang = 'AZ';

    }else if($lang == 'en'){
      require('en.php');
      $currentLang = 'EN';

    } else if($lang == 'ru'){
      require('ru.php');
      $currentLang = 'RU';
    }
    else{
      require('az.php');
      $currentLang = 'AZ';
    }
  }

 ?>