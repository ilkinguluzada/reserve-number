<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Admin_model extends CI_Model {

    function __construct(){
        parent::__construct();
    }
  
    function clear_cache() {
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
    }

    /*
    * Check Email Username
    */
    function check_email_username($username='',$email='') {
      $this->db->where('email',$email);
      $this->db->or_where('username',$username);
        $rows = count($this->db->get('user')->result_array());
        if($rows >0){
            return TRUE;
        }
        else{
            return FALSE;
        }     
              
    }

    /*
    * Check Email
    */
    function check_email($email='') {
        $this->db->where('email',$email);
        $rows = count($this->db->get('user')->result_array());
        if($rows >0){
            return TRUE;
        }
        else{
            return FALSE;
        }     
              
    }

    /*
    * Check Token
    */
    function check_token($token='') {
        $this->db->where('token',$token);
        $rows = count($this->db->get('user')->result_array());
        if($rows >0){
            return TRUE;
        }
        else{
            return FALSE;
        }    
    }

    /*
    * Escape String
    */
    function escapeString($val) {
        $db = get_instance()->db->conn_id;
        $val = mysqli_real_escape_string($db, $val);
        return $val;
    }

    /*
    * Get Extension
    */
    function get_extension($file) {
     $extension = explode(".", $file);
     $ext = end($extension);
     return $ext ? $ext : 'link';
    }

    /*
    * Get Filtered String
    */
    function get_filtered_string($string) {
        $string = trim($string);
        $string = preg_replace("/[^ \w]+/", "", $string);
        return $string;
    }

    /*
    * Generating Random String
    */
    function generate_random_string($length=12) {
      $str = "";
        $characters = array_merge(range('a','z'), range('0','9'));
        $max = count($characters) - 1;
        for ($i = 0; $i < $length; $i++) {
            $rand = mt_rand(0, $max);
            $str .= $characters[$rand];
        }
        return $str;
    }


    /*
    * Getting all categories
    */
    function get_categories(){
        $this->db->select('*');
        $this->db->from('categories');
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    } 

    /*
    * Getting all numbers by categorys
    */
    function get_numbers_by_category_id($category_id){
        return $this->db->get_where('numbers' , array('category_id'=>$category_id))->result();
    }

    /*
    * Getting seller location
    */
    function get_sellerlocations(){
        $this->db->select('*');
        $this->db->from('seller_locations');
        $query_result = $this->db->get();
        $result = $query_result->result_array();
        return $result;
    } 

}


