<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Admin extends CI_Controller {   
    
    function __construct() {
        parent::__construct();
        $this->load->model('admin_model');
        $this->load->database();
        //cache controling
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        
    }
    
    /*
    * Dedault Index
    */
    public function index(){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url() . 'login', 'refresh');
        if ($this->session->userdata('admin_is_login') == 1)
            redirect(base_url() . 'admin/dashboard', 'refresh');
    }
    
    /*
    * Showing Dashboard
    */
    function dashboard(){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');
        /* start menu active/inactive section*/
        $this->session->unset_userdata('active_menu');
        $this->session->set_userdata('active_menu', '1');
        /* end menu active/inactive section*/
        $data['page_name']             = 'dashboard';
        $data['page_title']            = 'Admin Dashboard';
        $this->load->view('admin/index', $data);        
            
    }

    /*
    * Viewing Form in Modal
    */
    function view_modal($page_name = '' , $param2 = '' , $param3 = ''){
            $account_type       =   $this->session->userdata('login_type');
            $data['param2']     =   $param2;
            $data['param3']     =   $param3;
            $this->load->view('admin/'.$page_name.'.php' ,$data);        
        
    }
    
    /*
    * Deleting Record
    */
    function delete_record(){
            $response           = array();
            $row_id             = $this->input->post('row_id');
            $table_name         = $this->input->post('table_name');
            $table_row_id       =$table_name.'_id';
            $this->db->where($table_row_id , $row_id);
            $query=$this->db->delete($table_name);
            if($query==true){
            $response['status']  = 'success';
            $response['message'] = tr_wd('Deleted successfully !');
            }
            else{
            $response['status']  = 'error';
            $response['message'] = 'Unable to delete record ...';
            }        
            echo json_encode($response);
        
    }

    /*
    * Deleting Record
    */
    function delete_book(){
            $response           = array();
            $row_id             = $this->input->post('row_id');
            $table_name         = $this->input->post('table_name');
            $table_row_id       ='id';
            $this->db->where($table_row_id , $row_id);
            $query=$this->db->delete($table_name);
            if($query==true){
            $response['status']  = 'success';
            $response['message'] = tr_wd('Deleted successfully !');
            }
            else{
            $response['status']  = 'error';
            $response['message'] = 'Unable to delete record ...';
            }        
            echo json_encode($response);
        
    }

    /*
    * Manage User
    */
    function manage_user($param1 = '', $param2 = ''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

        /* start menu active/inactive section*/
        $this->session->unset_userdata('active_menu');
        $this->session->set_userdata('active_menu', '15');
        /* end menu active/inactive section*/ 
        
        if ($param1 == 'add') {
            $data['name']           = $this->input->post('name');
            $data['username']       = $this->input->post('username');
            $data['password']       = md5($this->input->post('password'));
            $data['email']          = $this->input->post('email');
            $data['role']           = $this->input->post('role');           
            
            $this->db->insert('user', $data);
            $this->session->set_flashdata('success', 'User added successed');
            redirect(base_url() . 'admin/manage_user/', 'refresh');
        }

        if ($param1 == 'update') {
            $data['name']           = $this->input->post('name');
            $data['username']       = $this->input->post('username');
            if($this->input->post('password')!='' || $this->input->post('password')!=NULL){
                $data['password']   = md5($this->input->post('password'));
            }
            
            $data['email']          = $this->input->post('email');
            $data['role']           = $this->input->post('role');

            $this->db->where('user_id', $param2);
            $this->db->update('user', $data);
            $this->session->set_flashdata('success', 'User update successed.');
            redirect(base_url() . 'admin/manage_user/', 'refresh');
        }       

        if ($param1 == 'delete') {
            $response = array();
            $user_id           = $this->input->post('user_id');
            $this->db->where('user_id', $user_id);
            $run=$this->db->delete('user');
            if($run){
                $response['status']  = 'success';
                $response['message'] = 'Product Deleted Successfully ...';
            }
            else {
                $response['status']  = 'error';
                $response['message'] = 'Unable to delete product ...';
            }
                echo json_encode($response);
        }
        
            $data['page_name']      = 'user_manage';
            $data['page_title']     = 'User Management';
            $data['users']    = $this->db->get('user')->result_array(); 
            $this->load->view('admin/index', $data);
    }

    /*
    * Numbers Add
    */
    function numbers_add(){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '4');
            /* end menu active/inactive section*/

            $data['categories'] = $this->admin_model->get_categories();

            $data['page_name']      = 'numbers_add';
            $data['page_title']     = 'Number Add'; 
            $this->load->view('admin/index', $data);
    }

    /*
    * Numbers Edit
    */
    function numbers_edit($param1='',$param2=''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');
            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '4');
            /* end menu active/inactive section*/

            $data['categories'] = $this->admin_model->get_categories();

            $data['param1']         = $param1;
            $data['param2']         = $param2;
            $data['page_name']      = 'numbers_edit';
            $data['page_title']     = 'Number Edit';
            $this->load->view('admin/index', $data);
    }

    /*
    * Numbers General
    */
    function numbers($param1 = '', $param2 = ''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '5');
            /* end menu active/inactive section*/   
        
        if ($param1 == 'add') {            
            $data['prefix']  = $this->input->post('prefix');
            $data['number']  = $this->input->post('number');
            $data['price']  = $this->input->post('price');
            $data['category_id']  = $this->input->post('category_id');

            $this->db->insert('numbers', $data);
            $insert_id = $this->db->insert_id();          
            
            $this->session->set_flashdata('success', 'number added successed');
            redirect(base_url() . 'admin/numbers/', 'refresh');
        }
        else if ($param1 == 'update') {
            $data['prefix']  = $this->input->post('prefix');
            $data['number']  = $this->input->post('number');
            $data['price']  = $this->input->post('price');
            $data['category_id']  = $this->input->post('category_id');

            $this->db->where('id', $param2);
            $this->db->update('numbers', $data);

            $this->session->set_flashdata('success', 'Number Updated.');
            redirect(base_url() . 'admin/numbers/', 'refresh');
        }
        else{
            if($param1 != '' && $param1!=NULL ) $data['type']      = $param1;
            else $data['type']      = '';
            
        }
            $data['page_name']      = 'numbers_manage';
            $data['page_title']     = 'Number Management';          
            $this->load->view('admin/index', $data);
    }

    /*
    * Categories Add
    */
    function categories_add(){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '6');
            /* end menu active/inactive section*/

            $data['categories'] = $this->admin_model->get_categories();

            $data['page_name']      = 'categories_add';
            $data['page_title']     = 'Category Add'; 
            $this->load->view('admin/index', $data);
    }

    /*
    * Categories Edit
    */
    function categories_edit($param1='',$param2=''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '6');
            /* end menu active/inactive section*/

            $data['categories'] = $this->admin_model->get_categories();

            $data['param1']         = $param1;
            $data['param2']         = $param2;
            $data['page_name']      = 'categories_edit';
            $data['page_title']     = 'Category Edit';
            $this->load->view('admin/index', $data);
    }

    /*
    * Categories General
    */
    function categories($param1 = '', $param2 = ''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '7');
            /* end menu active/inactive section*/   
        
        if ($param1 == 'add') {            
            $data['category']  = $this->input->post('category');
            $data['starting_price']  = $this->input->post('starting_price');
            $data['description']  = $this->input->post('description');

            $this->db->insert('categories', $data);
            $insert_id = $this->db->insert_id();          

            $this->session->set_flashdata('success', 'category added successed');
            redirect(base_url() . 'admin/categories/', 'refresh');
        }
        else if ($param1 == 'update') {
            $data['category']  = $this->input->post('category');
            $data['starting_price']  = $this->input->post('starting_price');
            $data['description']  = $this->input->post('description');

            $this->db->where('id', $param2);
            $this->db->update('categories', $data);

            $this->session->set_flashdata('success', ' update successed.');
            redirect(base_url() . 'admin/categories/', 'refresh');
        }
        else{
            if($param1 != '' && $param1!=NULL ) $data['type']      = $param1;
            else $data['type']      = ''; 
        }
            $data['page_name']      = 'categories_manage';
            $data['page_title']     = 'Category Management';          
            $this->load->view('admin/index', $data);
    }



    /*
    * Seller Locations Add
    */
    function sellerlocations_add(){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '8');
            /* end menu active/inactive section*/

            $data['categories'] = $this->admin_model->get_sellerlocations();

            $data['page_name']      = 'sellerlocations_add';
            $data['page_title']     = 'Seller Location Add'; 
            $this->load->view('admin/index', $data);
    }

    /*
    * Seller Locations Edit
    */
    function sellerlocations_edit($param1='',$param2=''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '8');
            /* end menu active/inactive section*/

            $data['categories'] = $this->admin_model->get_sellerlocations();

            $data['param1']         = $param1;
            $data['param2']         = $param2;
            $data['page_name']      = 'sellerlocations_edit';
            $data['page_title']     = 'Seller Location Edit';
            $this->load->view('admin/index', $data);
    }

    /*
    * Seller Locations General
    */
    function sellerlocations($param1 = '', $param2 = ''){
        if ($this->session->userdata('admin_is_login') != 1)
            redirect(base_url(), 'refresh');

            /* start menu active/inactive section*/
            $this->session->unset_userdata('active_menu');
            $this->session->set_userdata('active_menu', '9');
            /* end menu active/inactive section*/   
        
        if ($param1 == 'add') {            
            $data['name']  = $this->input->post('name');
            $data['address']  = $this->input->post('address');
            $data['phone']  = $this->input->post('phone');
            $data['lat']  = $this->input->post('lat');
            $data['lng']  = $this->input->post('lng');

            $this->db->insert('seller_locations', $data);
            $insert_id = $this->db->insert_id();          

            $this->session->set_flashdata('success', 'seller location added successed');
            redirect(base_url() . 'admin/sellerlocations/', 'refresh');
        }
        else if ($param1 == 'update') {
            $data['name']  = $this->input->post('name');
            $data['address']  = $this->input->post('address');
            $data['phone']  = $this->input->post('phone');
            $data['lat']  = $this->input->post('lat');
            $data['lng']  = $this->input->post('lng');

            $this->db->where('id', $param2);
            $this->db->update('seller_locations', $data);

            $this->session->set_flashdata('success', 'Update successed.');
            redirect(base_url() . 'admin/sellerlocations/', 'refresh');
        }
        else{
            if($param1 != '' && $param1!=NULL ) $data['type']      = $param1;
            else $data['type']      = ''; 
        }
            $data['page_name']      = 'sellerlocations_manage';
            $data['page_title']     = 'Seller Location Management';          
            $this->load->view('admin/index', $data);
    }


}