<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
    }

	public function index(){
		$method = $_SERVER['REQUEST_METHOD'];
		if($method != 'GET'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {
		    $resp = $this->api_model->book_popular();
	    	json_output(200,$resp);
		}
	}

	public function number($action, $prefix=null, $number=null, $category_id=null){

		switch ($action) {
			case 'search':
				$method = $_SERVER['REQUEST_METHOD'];
				if($method != 'GET'){
					json_output(400,array('status' => 400,'message' => 'Bad request.'));
				} else {
			        $resp = $this->api_model->search_number($number, $prefix, $category_id);
					json_output(200,$resp);
				}
			break;
			
			case 'reserve':
				$method = $_SERVER['REQUEST_METHOD'];
				if($method != 'POST'){
					json_output(400,array('status' => 400,'message' => 'Bad request.'));
				} else {
			        $resp = $this->api_model->reserve_number($_POST['number_id'], $_POST['phone']);
					json_output(200,$resp);
				}
			break;

			default:
				# code...
				break;
		}
	}
}
