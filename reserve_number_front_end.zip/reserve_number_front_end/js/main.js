$(document).ready(function() {


	//Modal
	$('.modal').modal();

   //Modal Close
   $("#cancel-btn").click(function(e){
      e.preventDefault();
      $('.modal').modal('close');
   });

   //Carousel
   $('.carousel').carousel();

   //Reset Button
   $("#reset-btn").click(function(){
      $("#search-form")[0].reset();
      //$("select").prop('selectedIndex', 0);
      //$("select").formSelect();
   });

   //Tooltip
   $('.tooltipped').tooltip();
	

   //Search Action
   $("#search-btn").click(function(e){
   	e.preventDefault();
   	$("#search-form").toggle();
   	$(".loading").toggle();

   	//Do ajax request here

   	//If request was successful
   	setTimeout(function(){ 
         $(".loading").toggle();
         $(".result").toggle();
   	 }, 3000);
   });

   //Seach Again Action
   $("#search-again").click(function(e){
      e.preventDefault();
      $("#search-form").toggle();
      $(".result").toggle();
   });

   //Reserve Action
   $("#reserve-btn").click(function(e){
      e.preventDefault();
      $("#reserve-form").toggle();
      $(".loading-form").toggle();

      //Do ajax request here

      //If request was successful
      setTimeout(function(){ 
         $(".loading-form").toggle();
         $("#success-msg").toggle();
       }, 3000);
   });
});